# Load required libraries
library(dplyr)
library(lubridate)

# Load the dataset
employees <- read.csv("Employees data.csv", stringsAsFactors = FALSE)

# Handle missing values
employees$Name[is.na(employees$Name)] <- "Unknown"
employees$Department[is.na(employees$Department)] <- "Unassigned"
employees$Salary[is.na(employees$Salary)] <- mean(employees$Salary, na.rm = TRUE)
employees <- employees[!is.na(employees$Age) & !is.na(employees$DOB), ]

# Standardize column formats
employees$DOB <- as.Date(employees$DOB, format="%Y-%m-%d")
employees$Joining_Date <- as.Date(employees$Joining_Date, format="%Y-%m-%d")
employees$Performance_Score <- as.factor(employees$Performance_Score)

# Create new derived columns
employees$Tenure <- as.numeric(difftime(Sys.Date(), employees$Joining_Date, units = "days")) / 365
employees$Experience_Level <- cut(employees$Tenure, 
                                  breaks = c(-Inf, 1, 5, 10, Inf),
                                  labels = c("New", "Junior", "Mid", "Senior"))

# Save the cleaned dataset
write.csv(employees, "cleaned_employees.csv", row.names = FALSE)

print("Data cleaning completed successfully!")
